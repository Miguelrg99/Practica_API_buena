﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Beca.Canaldeportes.API.Entities
{
    public class deportes
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Titulo { get; set; }

        [MaxLength(300)]
        public string? Descripcion { get; set; }

        public ICollection<Canal> canales { get; set; }
            = new List<Canal>();

        public deportes(string titulo)
        {
            Titulo = titulo;
        }




    }
}
