﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Beca.Canaldeportes.API.Entities
{
    public class Canal
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; } 

        [Required]
        [MaxLength(50)]
        public string Titulo { get; set; } = string.Empty;

        [MaxLength(300)]
        public string? Descripcion { get; set; }

        [ForeignKey("CanalesId")]
        public deportes? Deportes {get; set; }
        public int CanalId {get; set; }

        public Canal(string titulo)
        {
            Titulo = titulo;
        }
      

    }
}
