﻿using AutoMapper;

namespace Beca.Canaldeportes.API.Profiles
{
    public class CanalesProfile : Profile
    {
        public CanalesProfile()
        {
            CreateMap<Entities.Canal, Models.CanalDto>();
            CreateMap<Models.CanalForCreationDto, Entities.Canal>();
            CreateMap<Models.CanalForUpdateDto, Entities.Canal>();
            CreateMap<Entities.Canal, Models.CanalForUpdateDto>();
        }

    }
}
