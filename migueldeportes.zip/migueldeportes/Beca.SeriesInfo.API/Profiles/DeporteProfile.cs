﻿using AutoMapper;

namespace Beca.Canaldeportes.API.Profiles
{
    public class CanalProfile : Profile
    {
        public CanalProfile()
        {
            CreateMap<Entities.deportes, Models.DeportesWithOutCanales>();
            CreateMap<Entities.deportes, Models.DeportesDto>();
        }
    }
}
