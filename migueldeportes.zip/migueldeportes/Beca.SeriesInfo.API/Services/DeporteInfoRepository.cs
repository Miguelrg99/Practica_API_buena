﻿using Beca.Canaldeportes.API.DbContexts;
using Beca.Canaldeportes.API.Entities;
using Microsoft.EntityFrameworkCore;
using SQLitePCL;

namespace Beca.Canaldeportes.API.Services
{
    

    public class DeportesInfoRepository : IDeportesInfoRepository
    {
        private readonly DeportesInfoContext _context;
        public DeportesInfoRepository(DeportesInfoContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<Canal?> GetDeportesForCanalesAsync(int deportesId, int canalesId)
        {
            return await _context.Canales.Where(c => c.CanalId == deportesId &&
            c.Id == canalesId).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Canal>> GetDeportesForCanalesAsync(int deportesId)
        {
            return await _context.Canales.Where(c => c.CanalId == deportesId).ToListAsync();
        }

        public async Task<deportes?> GetDeportesAsync(int deportesId, bool includeCanales)
        {
            if (includeCanales)
            {
                return await _context.Deportes.Include(s => s.canales).
                    Where(c => c.Id == deportesId).FirstOrDefaultAsync();
            }
            return await _context.Deportes.Where(s => s.Id == deportesId).FirstOrDefaultAsync();
        }
        public async Task<IEnumerable<deportes>> GetDeportesAsync(string? titulo, string? searchQuery, int pageNumber, int pageSize)
        {
           
            var collection = _context.Deportes as IQueryable<deportes>;

            if (!string.IsNullOrEmpty(titulo))
            {
                titulo = titulo.Trim();
                collection = collection.Where(c => c.Titulo == titulo);
            }

            if (!string.IsNullOrWhiteSpace(searchQuery))
            {
                searchQuery = searchQuery.Trim();
                collection = collection.Where(a => a.Titulo.Contains(searchQuery)
                || (a.Descripcion != null && a.Descripcion.Contains(searchQuery)));
            }
            return await collection.OrderBy(c => c.Titulo).Skip(pageSize*(pageNumber-1)).Take(pageSize).ToListAsync();

           
       
        }

        public async Task<bool> CanalExistsAsync(int deportesId)
        {
            return await _context.Deportes.AnyAsync(s => s.Id == deportesId);
        }

        public void DeleteCanal(Canal canal)
        {
            _context.Canales.Remove(canal);
        }

        public async Task<IEnumerable<deportes>> GetDeportesAsync()
        {
            return await _context.Deportes.OrderBy(s=>s.Titulo).ToListAsync();
        }

        public async Task AddCanalForDeporteAsync(int deportesId, Canal canal)
        {
            var deportes = await GetDeportesAsync(deportesId, false);
            if(deportes != null)
            {
                deportes.canales.Add(canal);
            }
        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _context.SaveChangesAsync() >= 0);
        }
    }
}
