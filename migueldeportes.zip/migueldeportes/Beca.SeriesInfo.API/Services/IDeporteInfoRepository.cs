﻿using Beca.Canaldeportes.API.Entities;

namespace Beca.Canaldeportes.API.Services
{
    public interface IDeportesInfoRepository
    {
        Task<IEnumerable<deportes>> GetDeportesAsync();
        Task<IEnumerable<deportes>> GetDeportesAsync(string? name, string? searchQuery, int pageNumber, int pageSize);
        

        Task<deportes?> GetDeportesAsync(int canalId, bool includeDeportes);

        Task<IEnumerable<Canal>> GetDeportesForCanalesAsync(int canalId);

        Task<Canal?> GetDeportesForCanalesAsync(int canalId, int deporteId);

        Task<bool> CanalExistsAsync(int canalId);

        Task AddCanalForDeporteAsync(int canalId, Canal deporte);

        Task<bool> SaveChangesAsync();

        void DeleteCanal(Canal deporte);
    }
}
