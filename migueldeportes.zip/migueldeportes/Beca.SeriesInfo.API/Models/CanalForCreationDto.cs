﻿using System.ComponentModel.DataAnnotations;

namespace Beca.Canaldeportes.API.Models
{
    public class CanalForCreationDto
    {
        [Required(ErrorMessage = "Debes introducir un Canal")]
        [MaxLength(50)]
        public string Canal { get; set; } = string.Empty;

        [MaxLength(300)]
        public string? Descripcion { get; set; }

    }
}