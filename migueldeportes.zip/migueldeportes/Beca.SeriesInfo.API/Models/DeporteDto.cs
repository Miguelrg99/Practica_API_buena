﻿using Beca.Canaldeportes.API.Entities;

namespace Beca.Canaldeportes.API.Models
{
    public class DeportesDto
    {
        public int Id { get; set; }
        public string Titulo { get; set; } = string.Empty;
        public string? Descripcion { get; set; }  
        public int Num_deportes
        {
            get
            {
                return Deportes.Count;
            }
        }
        public ICollection<CanalDto> Deportes { get; set; }
            = new List<CanalDto>();
    }
}
