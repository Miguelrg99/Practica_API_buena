﻿using System.ComponentModel.DataAnnotations;

namespace Beca.Canaldeportes.API.Models
{
    public class CanalForUpdateDto
    {
        [Required(ErrorMessage = "Debes introducir un Canal")]
        [MaxLength(50)]
        public string Titulo { get; set; } = string.Empty;

        [MaxLength(300)]
        public string? Descripcion { get; set; }
    }
}
