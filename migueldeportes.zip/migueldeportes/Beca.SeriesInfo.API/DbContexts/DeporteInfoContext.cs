﻿using Beca.Canaldeportes.API.Entities;
using Microsoft.EntityFrameworkCore;

namespace Beca.Canaldeportes.API.DbContexts
{
    public class DeportesInfoContext : DbContext  

    {
        public DbSet<deportes> Deportes { get; set; } = null!;

        public DbSet<Canal> Canales { get; set; } = null!;


        public DeportesInfoContext(DbContextOptions<DeportesInfoContext> options)
            : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<deportes>()
                .HasData(
                new deportes("Futbol")
                {
                    Id = 1,
                    Descripcion = "Descripcion"
                },
                new deportes("Baloncesto")
                {
                    Id = 2,
                    Descripcion = "Descripcion"
                },
                new deportes("Rugby")
                {
                    Id = 3,
                    Descripcion = "Descripcion"
                },
                new deportes("Tenis")
                {
                      Id = 4,
                      Descripcion = "Descripcion"
                });
            modelBuilder.Entity<Canal>()
                .HasData(
                new Canal("Canal 1")
                {
                    Id= 1,
                    CanalId = 1,
                    Descripcion = "Descripcion"
                },
                new Canal("Canal 2")
                {
                     Id = 2,
                     CanalId = 2,
                     Descripcion = "Descripcion2"
                },
                new Canal("Canal 3")
                {
                     Id = 3,
                     CanalId = 3,
                     Descripcion = "Descripcion3"
                },
                new Canal("canal 4")
                {
                    Id = 4,
                    CanalId = 4,
                    Descripcion = "Descripcion4"
                },
                new Canal("Canal 5")
                {
                    Id = 5,
                    CanalId = 5,
                    Descripcion = "Descripcion5"
                }

                );
            base.OnModelCreating(modelBuilder);

        }
    }


}

