﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Beca.Canaldeportes.API.Migrations
{
    public partial class DataSeed : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Deportes",
                columns: new[] { "Id", "Descripcion", "Deporte" },
                values: new object[] { 1, "Descripcion", "futbol" });

            migrationBuilder.InsertData(
                table: "Deportes",
                columns: new[] { "Id", "Descripcion", "Deporte" },
                values: new object[] { 2, "Descripcion", "baloncesto" });

            migrationBuilder.InsertData(
                table: "Deportes",
                columns: new[] { "Id", "Descripcion", "Deporte" },
                values: new object[] { 3, "Descripcion", "Rugby" });

            migrationBuilder.InsertData(
                table: "Deportes",
                columns: new[] { "Id", "Descripcion", "CanalId", "Canal" },
                values: new object[] { 4, "Descripcion", 1, "Canal Tenis" });

            migrationBuilder.InsertData(
                table: "Deportes",
                columns: new[] { "Id", "Descripcion", "CanalId", "Canal" },
                values: new object[] { 2, "Descripcion2", 2, "Canal baloncesto" });

            migrationBuilder.InsertData(
                table: "Deportes",
                columns: new[] { "Id", "Descripcion", "CanalId", "Canal" },
                values: new object[] { 3, "Descripcion3", 3, "Canal Rugby" });

            migrationBuilder.InsertData(
                table: "Deportes",
                columns: new[] { "Id", "Descripcion", "CanalId", "Canal" },
                values: new object[] { 4, "Descripcion4", 4, "Canal Tenis" });

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Deportes",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Deportes",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Deportes",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Deportes",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Deportes",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Deportes",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Deportes",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Deportes",
                keyColumn: "Id",
                keyValue: 3);
            migrationBuilder.DeleteData(
                table: "Deportes",
                keyColumn: "Id",
                keyValue: 4);
        }
    }
}
