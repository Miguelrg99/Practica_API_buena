﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Beca.Canaldeportes.API.Migrations
{
    public partial class dataSeed2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Deportes",
                columns: new[] { "Id", "Descripcion", "Deportes" },
                values: new object[] { 4, "Descripcion", "Tenis" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Deportes",
                keyColumn: "Id",
                keyValue: 4);
        }
    }
}
