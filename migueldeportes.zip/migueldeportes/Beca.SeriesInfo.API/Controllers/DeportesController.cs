﻿using AutoMapper;
using Beca.Canaldeportes.API.Models;
using Beca.Canaldeportes.API.Services;
using Microsoft.AspNetCore.Mvc;

namespace Beca.Canaldeportes.API.Controllers
{
    [ApiController]
    [Route("api/deportes")]
    public class DeportesController : ControllerBase
    {
        private readonly IDeportesInfoRepository _deportesInfoRepository;
        private readonly IMapper _mapper;
        const int maxDeportesPageSize = 30;

        public DeportesController(IDeportesInfoRepository deportesInfoRepository, IMapper mapper)
        {
            _deportesInfoRepository = deportesInfoRepository ??
                throw new ArgumentNullException(nameof(deportesInfoRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DeportesWithOutCanales>>> GetSeries(string? titulo, string? searchQuery, int pageNumber=1, int pageSize=10)
        {
            if(pageSize > maxDeportesPageSize)
            {
                pageSize = maxDeportesPageSize;
            }
            var deportesEntities = await _deportesInfoRepository.GetDeportesAsync(titulo, searchQuery, pageNumber, pageSize);
           
            return Ok(_mapper.Map<IEnumerable<DeportesWithOutCanales>>(deportesEntities));
        
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetDeporte( int id, bool includeCanales = false)
        {
            var deporte = await _deportesInfoRepository.GetDeportesAsync(id, includeCanales);
            if( deporte == null)
            {
                return NotFound();
            }
            if (includeCanales)
            {
                return Ok(_mapper.Map<DeportesDto>(deporte));
            }
            return Ok(_mapper.Map<DeportesWithOutCanales>(deporte));

        }
        

    }
}
