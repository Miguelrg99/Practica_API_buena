﻿using AutoMapper;
using Beca.Canaldeportes.API.Models;
using Beca.Canaldeportes.API.Services;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;

namespace Beca.Canaldeportes.API.Controllers
{
    [Route("api/deportes/{deportesId}/canales")]
    [ApiController]
    public class CanalesController : ControllerBase
    {
        private readonly IDeportesInfoRepository _deportesInfoRepository;
        private readonly IMapper _mapper;
        public CanalesController(IDeportesInfoRepository canalesInfoRepository, IMapper mapper)
        {
            _deportesInfoRepository = canalesInfoRepository ?? throw new ArgumentNullException(nameof(canalesInfoRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));

        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CanalDto>>> GetCanales(int canalId)
        {
            if (!await _deportesInfoRepository.CanalExistsAsync(canalId))
            {
                return NotFound();
            }
            var capitulosForSerie = await _deportesInfoRepository.GetDeportesForCanalesAsync(canalId);

            return Ok(_mapper.Map<IEnumerable<CanalDto>>(capitulosForSerie));

        }
        [HttpGet("{canalId}", Name = "GetCanal")]
        public async Task<ActionResult<CanalDto>> GetCanal(int deporteId, int canalId)
        {
            if (!await _deportesInfoRepository.CanalExistsAsync(deporteId))
            {
                return NotFound();
            }

            var capitulo = await _deportesInfoRepository.GetDeportesForCanalesAsync(deporteId, canalId);
            if (capitulo == null)
            {
                return NotFound();
            }

            return Ok(_mapper.Map<CanalDto>(capitulo));

        }

        [HttpPost]
        public async Task<ActionResult<CanalDto>> CreateCanal(int CanalId, CanalForCreationDto canal)
        {

            if (!await _deportesInfoRepository.CanalExistsAsync(CanalId))
            {
                return NotFound();
            }
            var finalCapitulo = _mapper.Map<Entities.Canal>(canal);
            await _deportesInfoRepository.AddCanalForDeporteAsync(CanalId, finalCapitulo);
            await _deportesInfoRepository.SaveChangesAsync();

            var createdCanalToReturn =
                _mapper.Map<Models.CanalDto>(finalCapitulo);

            return CreatedAtRoute("GetCanal",
                new
                {
                    s = CanalId,
                    canalId = createdCanalToReturn.Id
                },
                createdCanalToReturn);
        }
        [HttpPutAttribute("{canalId}")]
        public async Task<ActionResult> UpdateCapitulo(int deportesId, int canalId, CanalForUpdateDto canal)
        {
            if(!await _deportesInfoRepository.CanalExistsAsync(deportesId))
            {
                return NotFound();
            }
            var canalEntity = await _deportesInfoRepository.GetDeportesForCanalesAsync(deportesId, canalId);
            if(canalEntity == null)
            {
                return NotFound();
            }

            _mapper.Map(canal, canalEntity);

            await _deportesInfoRepository.SaveChangesAsync();

            return NoContent();
        }
        

        [HttpDelete("{canalId}")]
        public async Task<ActionResult> DeleteCanal(int deportesId, int canalId)
        {
            if(!await _deportesInfoRepository.CanalExistsAsync(deportesId))
            {
                return NotFound();
            }
            var canalEntity = await _deportesInfoRepository.GetDeportesForCanalesAsync(deportesId, canalId);
            if(canalEntity == null)
            {
                return NotFound();
            }

            _deportesInfoRepository.DeleteCanal(canalEntity);
            await _deportesInfoRepository.SaveChangesAsync();
            return NoContent();
        }
        
        
    }
}
